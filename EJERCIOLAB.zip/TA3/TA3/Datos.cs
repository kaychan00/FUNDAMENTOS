﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TA3
{
    internal class Datos
    {
        public string Nombre;
        public string Id;
        public string Dni;
        public int Edad;

    }
}
